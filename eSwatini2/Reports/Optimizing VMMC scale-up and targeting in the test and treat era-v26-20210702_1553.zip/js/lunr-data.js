var lunrData = [{"id":140279877,"title":"Optimizing VMMC scale-up and targeting in the test and treat era","link":"Optimizing_VMMC_scale-up_and_targeting_in_the_test_and_treat_era.html"}];
